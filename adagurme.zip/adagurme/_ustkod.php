<!DOCTYPE html>
<html lang="tr">

<head>

	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="description" content="">
	<meta name="author" content="">
	
	<link rel="icon" type="image/png" href="gorseller/favicon.png">

	<title>ADA GURME</title>
	
	<!-- CSS -->
	<link href="css/bootstrap.min.css" rel="stylesheet">
	<link href="css/owl.carousel.min.css" rel="stylesheet">
	<link href="css/owl.theme.default.min.css" rel="stylesheet">
	<link href="css/fotorama.css" rel="stylesheet">
	<link href="css/fancybox.css" rel="stylesheet">
	<link href="css/adagurme.css?v=<?=uniqid();?>" rel="stylesheet">
 

</head>
<body>
