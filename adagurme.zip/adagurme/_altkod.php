
<script src="js/jquery-3.6.3.min.js"></script>
<script src="js/popper.min.js"></script>
<script src="js/bootstrap.bundle.min.js"></script>
<script src="js/owl.carousel.min.js"></script>
<script src="js/fotorama.js"></script>
<script src="js/fancybox.umd.js"></script>
<script src="js/adagurme.js?v=<?=uniqid();?>"></script>

</body>
</html>